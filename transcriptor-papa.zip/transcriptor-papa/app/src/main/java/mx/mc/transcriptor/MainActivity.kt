package mx.mc.transcriptor

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity(), RecognitionListener {

    // ---------- Colores ----------
    private val BG = 0xFF131315.toInt()
    private val PANEL = 0xFF1D1D21.toInt()
    private val INK = 0xFFF7F7F5.toInt()
    private val MUTE = 0xFF9A9AA2.toInt()
    private val ACCENT = 0xFFFF5A3C.toInt()
    private val GREEN = 0xFF1F8A4C.toInt()
    private val COLORS = intArrayOf(
        0xFFFF5A3C.toInt(), 0xFF4A90F0.toInt(), 0xFF2BB673.toInt(), 0xFFB45AD6.toInt(),
        0xFFE0A800.toInt(), 0xFFE0457B.toInt(), 0xFF0AA5A5.toInt(), 0xFFA0805A.toInt()
    )

    data class Seg(val raw: String, var fixed: String?, var spk: Int, var guess: Boolean = false)

    private val segs = mutableListOf<Seg>()
    private lateinit var prefs: SharedPreferences
    private lateinit var scroll: ScrollView
    private lateinit var board: LinearLayout
    private lateinit var partialTv: TextView
    private lateinit var chipsRow: LinearLayout
    private lateinit var micBtn: Button
    private lateinit var aiTv: TextView

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var cur = 0
    private var muted = false
    private var lastErrorToast = 0L
    private val main = Handler(Looper.getMainLooper())
    private val aiExec = Executors.newSingleThreadExecutor()

    // ---------- Ajustes guardados ----------
    private fun str(k: String, d: String = "") = prefs.getString(k, d) ?: d
    private fun bool(k: String, d: Boolean) = prefs.getBoolean(k, d)
    private var fontSp: Float
        get() = prefs.getFloat("fs", 34f)
        set(v) { prefs.edit().putFloat("fs", v).apply() }
    private val names: List<String>
        get() = str("names", "Yo\nPapá\nOtra persona").split("\n")
            .map { it.trim() }.filter { it.isNotEmpty() }.take(8)
            .ifEmpty { listOf("Persona 1") }
    private val model: String
        get() = str("model", "gemini-flash-latest").trim().ifEmpty { "gemini-flash-latest" }

    private fun col(i: Int) = COLORS[((i % COLORS.size) + COLORS.size) % COLORS.size]
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    // ---------- Pantalla ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("tx", Context.MODE_PRIVATE)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.statusBarColor = BG
        @Suppress("DEPRECATION")
        window.navigationBarColor = PANEL

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        // Barra de arriba
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(8), dp(8))
        }
        val title = TextView(this).apply {
            text = "Transcriptor"
            setTextColor(INK)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        aiTv = TextView(this).apply {
            setTextColor(MUTE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, 0, dp(8), 0)
        }
        header.addView(aiTv)
        header.addView(smallBtn("A−") { fontSp = (fontSp - 4f).coerceAtLeast(18f); render() })
        header.addView(smallBtn("A+") { fontSp = (fontSp + 4f).coerceAtMost(90f); render() })
        header.addView(smallBtn("⚙") { openSettings() })
        root.addView(header)

        // Texto grande
        scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }
        board = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        partialTv = TextView(this).apply {
            typeface = Typeface.DEFAULT_BOLD
            setLineSpacing(0f, 1.1f)
        }
        content.addView(board)
        content.addView(partialTv)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Botones de quién habla
        val chipsScroll = HorizontalScrollView(this).apply {
            setBackgroundColor(PANEL)
            isHorizontalScrollBarEnabled = false
        }
        chipsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), dp(10), dp(10), 0)
        }
        chipsScroll.addView(chipsRow)
        root.addView(chipsScroll)

        // Botón de micrófono
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(PANEL)
            setPadding(dp(10), dp(10), dp(10), dp(12))
            gravity = Gravity.CENTER_VERTICAL
        }
        dock.addView(bigSide("✕") { confirmClear() })
        micBtn = Button(this).apply {
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { if (listening) stopListening() else startListening() }
        }
        dock.addView(micBtn, LinearLayout.LayoutParams(0, dp(76), 1f).apply {
            marginStart = dp(8); marginEnd = dp(8)
        })
        dock.addView(bigSide("⧉") { copyAll() })
        root.addView(dock)

        setContentView(root)
        updateMic()
        updateAiTv()
        renderChips()
        render()

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    private fun rounded(fill: Int, stroke: Int? = null, radius: Int = 14): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(radius).toFloat()
            setColor(fill)
            if (stroke != null) setStroke(dp(2), stroke)
        }

    private fun smallBtn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(INK)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        background = rounded(PANEL)
        minWidth = dp(52); minimumWidth = dp(52)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)).apply { marginStart = dp(6) }
        setOnClickListener { onClick() }
    }

    private fun bigSide(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(INK)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        background = rounded(0xFF2A2A30.toInt())
        layoutParams = LinearLayout.LayoutParams(dp(60), dp(76))
        setOnClickListener { onClick() }
    }

    private fun updateMic() {
        micBtn.text = if (listening) "Escuchando… (tocar para parar)" else "ESCUCHAR"
        micBtn.background = rounded(if (listening) GREEN else ACCENT, radius = 18)
    }

    private fun updateAiTv() {
        aiTv.text = when {
            !bool("ai", true) -> "IA apagada"
            str("key").isBlank() -> "IA: falta clave"
            else -> "IA activa"
        }
    }

    private fun renderChips() {
        chipsRow.removeAllViews()
        if (cur >= names.size) cur = 0
        names.forEachIndexed { i, n ->
            val sel = i == cur
            val b = Button(this).apply {
                text = n
                isAllCaps = false
                typeface = Typeface.DEFAULT_BOLD
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                setTextColor(if (sel) Color.WHITE else col(i))
                background = rounded(if (sel) col(i) else PANEL, col(i), 26)
                setPadding(dp(18), 0, dp(18), 0)
                setOnClickListener { cur = i; renderChips(); partialTv.setTextColor(col(cur)) }
            }
            chipsRow.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(52)).apply { marginEnd = dp(8) })
        }
        partialTv.setTextColor(col(cur))
    }

    private fun render() {
        board.removeAllViews()
        val fs = fontSp
        partialTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, fs)

        if (segs.isEmpty() && partialTv.text.isNullOrEmpty()) {
            board.addView(TextView(this).apply {
                text = "Toca ESCUCHAR y habla normal.\n\nAbajo toca el nombre de quién está hablando. " +
                        "Las palabras salen aquí en grande, con el color de cada persona.\n\n" +
                        "En ⚙ pones los nombres, el tema de la plática y tu clave de Gemini para que la IA corrija."
                setTextColor(MUTE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            })
            return
        }

        val n = segs.size
        val start = maxOf(0, n - 150)
        for (i in start until n) {
            val s = segs[i]
            val same = i > start && segs[i - 1].spk == s.spk
            if (!same) {
                board.addView(TextView(this).apply {
                    text = (names.getOrNull(s.spk) ?: "Persona ${s.spk + 1}") + if (s.guess) " ?" else ""
                    setTextColor(col(s.spk))
                    typeface = Typeface.DEFAULT_BOLD
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, maxOf(14f, fs * 0.42f))
                    setPadding(0, dp(10), 0, dp(2))
                })
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                alpha = if (i < n - 5) 0.55f else 1f
                setPadding(0, 0, 0, dp(6))
                setOnClickListener {
                    s.spk = (s.spk + 1) % names.size
                    s.guess = false
                    render()
                }
            }
            row.addView(View(this).apply { setBackgroundColor(col(s.spk)) },
                LinearLayout.LayoutParams(dp(5), ViewGroup.LayoutParams.MATCH_PARENT))
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), 0, 0, 0)
            }
            texts.addView(TextView(this).apply {
                text = s.fixed ?: s.raw
                setTextColor(if (s.fixed == null) MUTE else INK)
                typeface = Typeface.DEFAULT_BOLD
                setTextSize(TypedValue.COMPLEX_UNIT_SP, fs)
                setLineSpacing(0f, 1.1f)
            })
            val fx = s.fixed
            if (bool("raw", false) && fx != null && fx != s.raw) {
                texts.addView(TextView(this).apply {
                    text = "Se oyó: ${s.raw}"
                    setTextColor(MUTE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                })
            }
            row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            board.addView(row)
        }
        scrollDown()
    }

    private fun scrollDown() = scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }

    // ---------- Reconocimiento de voz ----------
    private fun buildIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-MX")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, bool("offline", false))
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            toast("Dale permiso de micrófono y vuelve a tocar ESCUCHAR")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Este celular no tiene reconocimiento de voz. Instala o actualiza la app de Google.")
            return
        }
        listening = true
        muteBeeps(true)
        updateMic()
        listenOnce()
    }

    private fun listenOnce() {
        if (!listening) return
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
            }
            recognizer?.startListening(buildIntent())
        } catch (e: Exception) {
            recognizer?.destroy(); recognizer = null
            main.postDelayed({ listenOnce() }, 500)
        }
    }

    private fun stopListening() {
        listening = false
        val pending = partialTv.text?.toString().orEmpty()
        partialTv.text = ""
        if (pending.isNotBlank()) addFinal(pending)
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        muteBeeps(false)
        updateMic()
    }

    private fun muteBeeps(on: Boolean) {
        if (on && !bool("mute", true)) return
        if (on == muted) return
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        for (st in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
            try {
                am.adjustStreamVolume(st, if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0)
            } catch (_: Exception) {}
        }
        muted = on
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onPartialResults(partialResults: Bundle?) {
        val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
        if (t.isBlank()) return
        val wasEmpty = segs.isEmpty() && partialTv.text.isNullOrEmpty()
        partialTv.text = t
        if (wasEmpty) render()
        scrollDown()
    }

    override fun onResults(results: Bundle?) {
        val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        partialTv.text = ""
        if (!t.isNullOrBlank()) addFinal(t)
        if (listening) main.postDelayed({ listenOnce() }, 60)
    }

    override fun onError(error: Int) {
        if (!listening) return
        var delay = 120L
        when (error) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                stopListening(); toast("Falta el permiso de micrófono"); return
            }
            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> {
                if (bool("offline", false)) {
                    prefs.edit().putBoolean("offline", false).apply()
                    toast("No está descargado el español sin internet. Sigo usando internet.")
                }
                recognizer?.destroy(); recognizer = null; delay = 400
            }
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                if (!bool("offline", false)) {
                    prefs.edit().putBoolean("offline", true).apply()
                    toast("Sin internet: cambio a reconocimiento sin conexión")
                }
                recognizer?.destroy(); recognizer = null; delay = 400
            }
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT,
            SpeechRecognizer.ERROR_SERVER_DISCONNECTED, SpeechRecognizer.ERROR_SERVER -> {
                try { recognizer?.destroy() } catch (_: Exception) {}
                recognizer = null; delay = 400
            }
        }
        val pending = partialTv.text?.toString().orEmpty()
        if (pending.isNotBlank()) { partialTv.text = ""; addFinal(pending) }
        main.postDelayed({ listenOnce() }, delay)
    }

    // ---------- Frases y corrección con IA ----------
    private fun addFinal(text: String) {
        val s = Seg(text.trim(), null, cur)
        segs.add(s)
        if (bool("ai", true) && str("key").isNotBlank()) enqueueFix(s) else s.fixed = s.raw
        render()
    }

    private fun enqueueFix(s: Seg) {
        val idx = segs.indexOf(s)
        val nm = names
        val prev = segs.subList(maxOf(0, idx - 10), idx)
            .joinToString("\n") { "${nm.getOrNull(it.spk) ?: "?"}: ${it.fixed ?: it.raw}" }
        val aiSpk = bool("aispk", false)
        val spkPart = if (aiSpk)
            "Personas en la plática: ${nm.joinToString(", ")}. Decide quién dijo la frase nueva por el contenido y el hilo " +
                    "(preguntas y respuestas, a quién se dirigen, cómo se nombran). Si no hay pista clara, asume que sigue hablando ${nm.getOrNull(s.spk)}."
        else "Esta frase la dijo: ${nm.getOrNull(s.spk)}."
        val prompt = """
Eres corrector de transcripciones de voz en español de México. Una familia platica con su papá, que es sordo y lee la transcripción en pantalla.
Contexto que dio la familia (tema, nombres): ${str("ctx").ifBlank { "(ninguno)" }}
$spkPart
Lo último que se dijo:
${prev.ifBlank { "(inicio de la plática)" }}

Frase nueva del reconocedor de voz (puede traer palabras mal reconocidas por sonar parecido):
"${s.raw}"

Corrige SOLO palabras que claramente se reconocieron mal por sonar parecido, usando el contexto. Pon puntuación, signos ¿? ¡! y mayúsculas. No cambies el sentido, no resumas, no agregues nada, conserva modismos y groserías mexicanas tal cual.
Responde solo con JSON así: {"texto":"frase corregida","hablante":"nombre exacto de la lista"}
""".trimIndent()
        val key = str("key").trim()
        val mdl = model
        aiExec.execute {
            var out: String? = null
            var err: String? = null
            try { out = callGemini(prompt, key, mdl) } catch (e: Exception) { err = e.message ?: "error" }
            main.post { applyFix(s, out, err, aiSpk) }
        }
    }

    private fun applyFix(s: Seg, out: String?, err: String?, aiSpk: Boolean) {
        if (out == null) {
            s.fixed = s.raw
            val now = System.currentTimeMillis()
            if (now - lastErrorToast > 20000) {
                lastErrorToast = now
                val e = err.orEmpty()
                toast(when {
                    e.contains("Unable to resolve host") || e.contains("timeout", true) -> "IA sin internet: muestro el texto tal cual"
                    e.contains("HTTP 400") || e.contains("HTTP 403") -> "Revisa tu clave de Gemini en ⚙"
                    e.contains("HTTP 404") -> "El modelo de IA no existe, revisa el nombre en ⚙"
                    e.contains("HTTP 429") -> "La IA va saturada (límite gratis), espera un momento"
                    else -> "IA: ${e.take(80)}"
                })
            }
        } else {
            val o = try {
                JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
            } catch (_: Exception) { null }
            val texto = o?.optString("texto")?.trim().orEmpty()
            s.fixed = texto.ifEmpty { if (o == null) out.trim().trim('"') else s.raw }.ifEmpty { s.raw }
            val h = o?.optString("hablante")?.trim().orEmpty()
            if (aiSpk && h.isNotEmpty()) {
                val k = names.indexOfFirst { it.equals(h, ignoreCase = true) }
                if (k >= 0) {
                    s.spk = k; s.guess = true
                    if (segs.lastOrNull() === s) { cur = k; renderChips() }
                }
            }
        }
        render()
    }

    private fun callGemini(prompt: String, key: String, mdl: String): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$mdl:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = 25000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", key)
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("temperature", 0.2).put("responseMimeType", "application/json"))
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw Exception("HTTP $code: ${text.take(200)}")
            val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (p.optBoolean("thought", false)) continue
                sb.append(p.optString("text"))
            }
            return sb.toString()
        } finally {
            conn.disconnect()
        }
    }

    // ---------- Botones ----------
    private fun copyAll() {
        if (segs.isEmpty()) { toast("No hay texto todavía"); return }
        val t = segs.joinToString("\n") { "${names.getOrNull(it.spk) ?: "?"}: ${it.fixed ?: it.raw}" }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Transcripción", t))
        toast("Texto copiado")
    }

    private fun confirmClear() {
        if (segs.isEmpty()) return
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setMessage("¿Borrar toda la plática de la pantalla?")
            .setPositiveButton("Borrar") { _, _ -> segs.clear(); partialTv.text = ""; render() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun openSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        fun label(t: String) = box.addView(TextView(this).apply {
            text = t
            typeface = Typeface.DEFAULT_BOLD
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setPadding(0, dp(14), 0, dp(4))
        })
        fun note(t: String) = box.addView(TextView(this).apply {
            text = t
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            alpha = 0.7f
        })
        fun field(v: String, hint: String, multi: Boolean, pass: Boolean = false) = EditText(this).apply {
            setText(v)
            this.hint = hint
            inputType = when {
                multi -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                pass -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                else -> InputType.TYPE_CLASS_TEXT
            }
            if (multi) { minLines = 3; gravity = Gravity.TOP or Gravity.START }
        }.also { box.addView(it) }
        fun check(t: String, k: String, d: Boolean) = CheckBox(this).apply {
            text = t
            isChecked = bool(k, d)
            setPadding(dp(4), dp(8), 0, dp(8))
        }.also { box.addView(it) }

        label("Personas que platican (una por renglón)")
        val eNames = field(names.joinToString("\n"), "Yo\nPapá\nOtra persona", true)
        label("Tema y nombres que se usan seguido")
        val eCtx = field(str("ctx"), "Ej.: Hablamos del rancho, la feria, el acordeón. Nombres: Doña Lupe, Aarón.", true)
        note("Con esto la IA atina mejor a los nombres y palabras de la familia.")
        label("Clave de Gemini (para corregir con IA)")
        val eKey = field(str("key"), "Pega aquí tu clave (empieza con AIza…)", false, pass = true)
        note("Se saca gratis en aistudio.google.com → Get API key.")
        label("Modelo de IA")
        val eModel = field(model, "gemini-flash-latest", false)
        label("Opciones")
        val cAi = check("Corregir con IA (necesita internet y clave)", "ai", true)
        val cSpk = check("La IA adivina quién habla (sale con ?)", "aispk", false)
        val cOff = check("Reconocer voz sin internet (necesita el paquete de español descargado)", "offline", false)
        val cMute = check("Silenciar pitidos del micrófono", "mute", true)
        val cRaw = check("Mostrar lo que se oyó antes de corregir", "raw", false)

        val sv = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Ajustes")
            .setView(sv)
            .setPositiveButton("Guardar") { _, _ ->
                prefs.edit()
                    .putString("names", eNames.text.toString())
                    .putString("ctx", eCtx.text.toString())
                    .putString("key", eKey.text.toString().trim())
                    .putString("model", eModel.text.toString().trim())
                    .putBoolean("ai", cAi.isChecked)
                    .putBoolean("aispk", cSpk.isChecked)
                    .putBoolean("offline", cOff.isChecked)
                    .putBoolean("mute", cMute.isChecked)
                    .putBoolean("raw", cRaw.isChecked)
                    .apply()
                if (listening) { recognizer?.destroy(); recognizer = null; listenOnce() }
                updateAiTv(); renderChips(); render()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Ciclo de vida ----------
    override fun onStop() {
        super.onStop()
        if (listening) stopListening()
    }

    override fun onDestroy() {
        super.onDestroy()
        muteBeeps(false)
        try { recognizer?.destroy() } catch (_: Exception) {}
        aiExec.shutdownNow()
    }
}
