# Transcriptor para papá

App de Android que transcribe en vivo en español de México con letra gigante, pone el nombre y el color de quién habla, y corrige con IA (Gemini) las palabras mal entendidas según el contexto de la plática.

## Cómo sale la APK
Cada vez que se sube un cambio a la rama `main`, GitHub Actions la compila sola (unos 5 minutos).
La APK queda en la pestaña **Releases** del repositorio como `TranscriptorPapa.apk`.
Todas las versiones se firman con la misma llave, así que cada versión nueva se instala encima de la anterior.

## Instalar en el celular
1. Abre la página del repositorio en el celular → **Releases** → descarga `TranscriptorPapa.apk`.
2. Ábrela. Si Android lo pide, permite "Instalar apps desconocidas" para tu navegador.
3. Abre **Transcriptor** y dale permiso de micrófono.

## Clave de Gemini (para la corrección con IA)
1. Entra a https://aistudio.google.com con tu cuenta de Google.
2. Dale a **Get API key** → **Create API key** y cópiala.
3. En la app: ⚙ → pega la clave → Guardar.

Sin clave o sin internet la app sigue transcribiendo; nada más no corrige.

## Para usarla sin internet
En el celular: Ajustes → Administración general → Idioma y entrada → Reconocimiento de voz de Google → Reconocimiento de voz sin conexión → descarga **Español (México)**.
Después, en la app: ⚙ → activa "Reconocer voz sin internet".
(El nombre exacto del menú cambia un poco según la versión de One UI.)

## Lo que sigue (versión 2)
- Reconocer a cada persona por su voz, sin internet (sherpa-onnx).
- Corrección con IA sin internet en el S25 Ultra (Gemini Nano).
